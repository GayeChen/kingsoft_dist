#!/usr/bin/env python
# -*- coding:utf-8 -*-

import socket

class RYSOCK():
    def __init__(self):
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

    def connect(self, proto, hostname, port, vpcid, remote_host, remote_port):
        self.sock.connect((hostname, port))
        self.sock.sendall("%s %s %s %s" % (proto, vpcid, remote_host, remote_port))

        recv = self.sock.recv(1024).strip()
        if recv == "Connected":
            return self.sock
        else:
            return None

    def tunnel(self, proto, vpcid, server, port):
        try:
            self.sock.connect((server, port))
            self.sock.sendall("%s %s" % (proto, vpcid))
        except socket.error, arg:
            #(errno, err_msg) = arg
            return None

        recv = self.sock.recv(1024).strip()
        if recv == "Connected":
            return self.sock
        else:
            return None

    def close(self):
        self.sock.close()

if __name__ == "__main__":
    s = RYSOCK()
    sock = s.connect("CONNECT", "localhost", 9999, "debian1", 22)
    print dir(sock)
