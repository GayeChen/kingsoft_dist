#! /usr/bin/env python
# -*- coding: utf-8 -*-

class RYCONFIG:
    tunnel = {}
    main = {}

def set_tunnel_config(name, value):
    RYCONFIG.tunnel[name] = value

def get_tunnel_config(name):
    return RYCONFIG.tunnel[name]

def set_main_config(name, value):
    RYCONFIG.main[name] = value

def get_main_config(name):
    return RYCONFIG.main[name]
